This repository contains a copy of the CMSIS DSP library sources as provided by ARM

Source URL: http://www.arm.com/products/processors/cortex-m/cortex-microcontroller-software-interface-standard.php
(click on Download CMSIS)

